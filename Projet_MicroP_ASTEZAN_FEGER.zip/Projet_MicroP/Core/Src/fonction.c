#include "main.h"
#include "stdio.h"
#include "max7219_Yncrea2.h"
#include "iks01a3_motion_sensors.h"
#include "iks01a3_motion_sensors_ex.h"
#include "stm32l1xx_nucleo_bus.h"
#include "iks01a3_env_sensors_ex.h"
#include "iks01a3_env_sensors.h"
#include "fonction.h"
#include <stdlib.h>
#include <time.h>

extern ADC_HandleTypeDef hadc;
extern TIM_HandleTypeDef htim3;


void BreatheSequence(uint32_t MyDelay){
	char i,j;
	for(i=0;i<=0x0F;i++)
	{
		j=0x0F-i;
		MAX7219_SetBrightness (j);
		HAL_Delay (MyDelay);
	}

	for (i=0;i<=0x0F; i++){
		MAX7219_SetBrightness (i);
		HAL_Delay (MyDelay) ;
	}
}

void setLEDs(int index, GPIO_PinState state) {
    switch (index) {
        case 0:
            HAL_GPIO_WritePin(L0_GPIO_Port, L0_Pin, state);
            HAL_GPIO_WritePin(L7_GPIO_Port, L7_Pin, state);
            break;
        case 1:
            HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, state);
            HAL_GPIO_WritePin(L6_GPIO_Port, L6_Pin, state);
            break;
        case 2:
            HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, state);
            HAL_GPIO_WritePin(L5_GPIO_Port, L5_Pin, state);
            break;
        case 3:
            HAL_GPIO_WritePin(L3_GPIO_Port, L3_Pin, state);
            HAL_GPIO_WritePin(L4_GPIO_Port, L4_Pin, state);
            break;
    }
}

void ledWaveAnimation(int repeatCount, int delayMs) {
    for (int j = 0; j < repeatCount; ++j) {
        // Allumer les LEDs en séquence
        for (int i = 0; i < 4; ++i) {
            setLEDs(i, GPIO_PIN_SET);
            HAL_Delay(delayMs);

            // Éteindre les LEDs de l'étape précédente si ce n'est pas le premier tour
            if (i > 0) {
                setLEDs(i - 1, GPIO_PIN_RESET);
            }
        }

        // Éteindre la dernière paire de LEDs
        setLEDs(3, GPIO_PIN_RESET);
    }
}

// Déclaration des ports et pins pour les LEDs
GPIO_TypeDef* LED_Ports[] = {L0_GPIO_Port, L1_GPIO_Port, L2_GPIO_Port, L3_GPIO_Port, L4_GPIO_Port, L5_GPIO_Port, L6_GPIO_Port, L7_GPIO_Port};
uint16_t LED_Pins[] = {L0_Pin, L1_Pin, L2_Pin, L3_Pin, L4_Pin, L5_Pin, L6_Pin, L7_Pin};

void TurnOffLEDs() {
    for (int i = 0; i < 8; i++) {
        HAL_GPIO_WritePin(LED_Ports[i], LED_Pins[i], GPIO_PIN_RESET);
    }
}

void BlinkPWM(int delay) {
    for (int i = 0; i < 3; i++) {
        HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
        HAL_Delay(delay);
        HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_2);
        HAL_Delay(delay);
    }
}

void DisplayFailMessage() {
    MAX7219_DisplayChar(1, 'F');
    MAX7219_DisplayChar(2, 'A');
    MAX7219_DisplayChar(3, 'I');
    MAX7219_DisplayChar(4, 'L');
}

// Fonction principale
void ErrorHandling() {
    TurnOffLEDs();
    BlinkPWM(100);
    DisplayFailMessage();
    BreatheSequence(100);
}

void printCool(void)
{
	 static const char alpha[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'H', 'I', 'J', 'L', 'O', 'P', 'Q', 'R', 'S', 'T', 'U'};
	 int index;
	   srand(time(NULL));

	 for (int digit = 1; digit <= 4; digit++)
	 {
		  // Afficher 9 caractères aléatoires pour chaque digit
		  for (int i = 0; i < 15; i++) {
			  index = rand() % (sizeof(alpha) / sizeof(alpha[0])); // Générer un index aléatoire
			  MAX7219_DisplayChar(digit, alpha[index]); // Afficher le caractère aléatoire sur le digit actuel
			  HAL_Delay(80); // Attendre 100 millisecondes entre chaque affichage
		  }
		  // Affichage de la dernière lettre spéciale pour chaque digit
		  if(digit == 1) {
			  MAX7219_DisplayChar(digit, 'C');
		  } else if(digit == 2) {
			  MAX7219_DisplayChar(digit, '0');
		  } else if(digit == 3) {
			  MAX7219_DisplayChar(digit, '0');
		  } else if(digit == 4) {
			  MAX7219_DisplayChar(digit, 'L');
		  }
		  HAL_Delay(100); // Attendre 100 millisecondes après l'affichage de la lettre spéciale
	  }
}

void adcFunction()
{
    static const char code[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    static const int digit[] = {1, 2, 3, 4}; // Utiliser les indices numériques pour les digits
    static int currentDigitIndex = 0; // Variable globale pour suivre le digit actuel
    //static GPIO_PinState prevButtonState = GPIO_PIN_SET;
    static char displayedCode[4] = {'0', '0', '0', '0'}; // Stocker les valeurs affichées

    uint32_t analogValue;
    int threshold = 0;

    // Démarrer l'ADC et lire la valeur
    HAL_ADC_Start_IT(&hadc);
    if(HAL_ADC_PollForConversion(&hadc, 1000) == HAL_OK){
        analogValue = HAL_ADC_GetValue(&hadc);
        //printf("ADC value: %lu\r\n", analogValue);
    }
    HAL_ADC_Stop_IT(&hadc);

    // Lire l'état actuel du bouton
    // Déclaration des variables d'état pour les deux boutons
    // Déclaration globale des variables d'état pour les boutons
    GPIO_PinState prevButtonState1 = GPIO_PIN_SET; // Initialisation à HAUT
    GPIO_PinState prevButtonState2 = GPIO_PIN_SET; // Initialisation à HAUT
    GPIO_PinState currentButtonState1 = HAL_GPIO_ReadPin(BTN1_GPIO_Port, BTN1_Pin);
    GPIO_PinState currentButtonState2 = HAL_GPIO_ReadPin(BTN2_GPIO_Port, BTN2_Pin);

    // Détecter l'appui sur le BTN1 (de l'état HAUT à BAS)
    if (currentButtonState1 == GPIO_PIN_RESET && prevButtonState1 == GPIO_PIN_SET) {
        // Passer au chiffre précédent (vers la gauche)
        if (currentDigitIndex == 0) {
            currentDigitIndex = 3; // Si on est au chiffre 1, passer directement au chiffre 4
        } else {
            currentDigitIndex = (currentDigitIndex - 1) % 4;
        }
        //printf("BTN1 pressed, current digit index: %d\r\n", currentDigitIndex); // Debugging output
    }

    // Détecter l'appui sur le BTN2 (de l'état HAUT à BAS)
    if (currentButtonState2 == GPIO_PIN_RESET && prevButtonState2 == GPIO_PIN_SET) {
        // Passer au chiffre suivant (vers la droite)
        currentDigitIndex = (currentDigitIndex + 1) % 4;
        //printf("BTN2 pressed, current digit index: %d\r\n", currentDigitIndex); // Debugging output
    }

    // Mettre à jour l'état précédent des boutons
    prevButtonState1 = currentButtonState1;
    prevButtonState2 = currentButtonState2;

    // Calculer et afficher le caractère correspondant
    for (int i = 0; i < 10; i++)
    {
    	if (analogValue > threshold && analogValue <= threshold + 410)
    	{
            displayedCode[currentDigitIndex] = code[i];
            MAX7219_DisplayChar(digit[currentDigitIndex], code[i]);
            break;
        }
        threshold += 410;
    }

    // Structure pour stocker les informations des broches
    typedef struct {
        GPIO_TypeDef* port1;
        uint16_t pin1;
        GPIO_TypeDef* port2;
        uint16_t pin2;
    } DigitPins;

    // Initialiser un tableau de structures avec les informations des broches
    DigitPins digitPins[4] = {
        {L7_GPIO_Port, L7_Pin, L6_GPIO_Port, L6_Pin},
        {L5_GPIO_Port, L5_Pin, L4_GPIO_Port, L4_Pin},
        {L3_GPIO_Port, L3_Pin, L2_GPIO_Port, L2_Pin},
        {L1_GPIO_Port, L1_Pin, L0_GPIO_Port, L0_Pin}
    };

    // Fonction pour mettre à jour les broches en fonction du digit courant
    void updateDigitPins(int currentDigitIndex) {
        for (int i = 0; i < 4; i++) {
            if (i == currentDigitIndex) {
                HAL_GPIO_WritePin(digitPins[i].port1, digitPins[i].pin1, GPIO_PIN_SET);
                HAL_GPIO_WritePin(digitPins[i].port2, digitPins[i].pin2, GPIO_PIN_SET);
            } else {
                HAL_GPIO_WritePin(digitPins[i].port1, digitPins[i].pin1, GPIO_PIN_RESET);
                HAL_GPIO_WritePin(digitPins[i].port2, digitPins[i].pin2, GPIO_PIN_RESET);
            }
        }
    }

    // Appel de la fonction pour mettre à jour les broches
    updateDigitPins(currentDigitIndex);

    if(HAL_GPIO_ReadPin(BTN4_GPIO_Port, BTN4_Pin)==0)
    {
		MAX7219_Clear();
		if (displayedCode[0] == '1' && displayedCode[1] == '2' && displayedCode[2] == '3' && displayedCode[3] == '4')
		{
		   printCool();
		   printf("OUVERTURE DU COFFRE...");
		   ledWaveAnimation(10, 150);
		}
		else
		{
		   ErrorHandling();
		}

    }
    HAL_Delay(200);
}
