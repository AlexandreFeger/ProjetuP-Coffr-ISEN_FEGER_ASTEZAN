#include "main.h"

void BreatheSequence(uint32_t MyDelay);
void setLEDs(int index, GPIO_PinState state);
void ledWaveAnimation(int repeatCount, int delayMs);
void adcFunction();
void printCool(void);
void TurnOffLEDs();
void BlinkPWM(int delay);
void DisplayFailMessage();
void Init_Motion_Sensor(void);
